import React from 'react'

function Bookings() {
  return (
    <div>s</div>
  )
}

export default Bookings;