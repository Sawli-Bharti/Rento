async function fetchBySearchInput(input) {
    try{
        const res=await fetch(`http://localhost:8080/property/search?query=${input}`);
        if(!res.ok){
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        const data=await res.json();
        return data;
    }catch(e){
        console.log('Fetch by search input error:', e);
        throw e;
    }

}
async function fetchAllProperties(url,setError) {
    try{
        const res=await fetch(url);
        if(!res.ok){
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        const data=await res.json();
        setError(null);
        return data;
    }catch(err){
        
         if (err instanceof SyntaxError) {
          console.error('Failed to parse JSON:', err);
          setError('Failed to load properties: Invalid data from server');
          setProperties([]);
        } else {
          console.log('Fetch error:', err);
          setError(`Failed to load properties: ${err.message}`);
          setProperties([]);
        }
        
    }
    
}

async function fetchPropertyById(id,setError){
    try{
        const res=await fetch(`http://localhost:8080/property/get/${id}`);
        if(!res.ok){
            setError(`Failed to load property: ${res.statusText}`);
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        const data=await res.json();
        console.log(data);
        setError(null);
        return data;
    }catch(err){
        setError(`Failed to load property: ${err.message}`);
        console.log('Fetch property by ID error:', err);
        throw err;
    }
}
export {fetchAllProperties,fetchBySearchInput,fetchPropertyById};