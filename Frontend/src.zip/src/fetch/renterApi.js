const BASE = "http://localhost:8080";

export const authFetch = async (url, token, options = {}) => {
  if (!token) {
    throw new Error("Missing auth token");
  }

  const fullUrl = BASE + url;
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
    ...(options.headers || {}),
  };
  console.log("authFetch", fullUrl, options.method || "GET", headers);

  const res = await fetch(fullUrl, {
    ...options,
    headers,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || "Request failed");
  }

  return res.json();
};
