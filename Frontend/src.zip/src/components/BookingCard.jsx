const BookingCard = ({property}) => {
  return (
    <div className="border rounded-lg p-4 flex justify-between items-center">
      <div>
        <h3 className="font-semibold">1 BHK Apartment</h3>
        <p className="text-sm text-slate-500">
          Andheri West, Mumbai
        </p>
        <p className="text-sm mt-1">
          Status: <span className="text-green-600">CONFIRMED</span>
        </p>
      </div>

      <button className="text-indigo-600 text-sm">
        View Details
      </button>
    </div>
  );
};
export default BookingCard;