import { useEffect, useState } from "react";
import { useAuth } from "../../../resource";
import { authFetch } from "../../../fetch/renterApi";

const MyBookings = () => {
  const { token,user } = useAuth();
  const [bookings, setBookings] = useState([]);

  // wait for auth info before calling
  useEffect(() => {
    if (token && user && user.renterId) {
      authFetch(`/bookings/renter/${user.renterId}`, token)
        .then(setBookings)
        .catch(console.error);
    }
  }, [token, user]);

  if (!bookings.length)
    return <p>No bookings yet</p>;

  return (
    <div>
      <h1 className="text-xl font-bold mb-4">My Bookings</h1>

      <div className="space-y-4">
        {bookings.map(b => (
          <div key={b.id} className="border p-4 rounded-lg">
            <h3 className="font-semibold">{b.propertyTitle}</h3>
            <p className="text-sm">{b.city}</p>
            <p className="text-sm mt-1">
              Status: <b>{b.status}</b>
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyBookings;
